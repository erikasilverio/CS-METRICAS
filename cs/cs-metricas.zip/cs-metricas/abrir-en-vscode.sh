#!/bin/sh
cd "$(dirname "$0")"
if command -v code >/dev/null 2>&1; then code . index.html; else echo "No se encontro VS Code en el PATH. Abri la carpeta desde VS Code: File > Open Folder."; fi
