@echo off
cd /d "%~dp0"
where code >nul 2>nul
if %errorlevel%==0 (code . index.html) else (echo No se encontro VS Code en el PATH. Abri la carpeta desde VS Code: File ^> Open Folder. & pause)
